from django.shortcuts import render
from.models import Post


posts = [
      {
      		'author': 'CoreyMS',
      		'title': 'Blog Post 1',
      		'content': 'first post',
      		'date_posted': 'April 19,2019'
     },
     {
      		'author': 'santhu',
      		'title': 'bhai stud',
      		'content': 'thop',
      		'date_posted': 'march 23,2019'
     }
]
# Create your views here.
def home(request):
	context = {
	   	'posts':Post.objects.all()
	}
	return render(request, 'blog/home.html', context)

def about(request):
	return render(request,'blog/about.html', {'title': 'About'})
