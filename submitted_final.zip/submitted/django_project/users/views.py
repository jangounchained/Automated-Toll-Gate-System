from django.shortcuts import render, redirect
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from django.contrib.auth.decorators import login_required
from .forms import UserRegistrationForm, addacountform, ChangeProfileForm
from .models import Profile
from django.contrib.auth.forms import UserChangeForm

# Create your views here.
def register(request):
	if  request.method == 'POST':
		form = UserRegistrationForm(request.POST)
		if form.is_valid():
			form.save()
			return redirect('edit_profile')
	else:
		form= UserRegistrationForm()
	return render (request, 'users/register.html',{'form':form})

@login_required
def profile(request):
	if  request.method == 'POST':
		a_form = addacountform(request.POST, request.FILES, instance=request.user.profile)
		if a_form.is_valid():
			a_form.save()

#			acc_bal =  a_form.cleaned_data.get('acc_bal') + acc_bal.value
			return redirect('profile')
	else:
		a_form = addacountform(instance=request.user.profile)
	context = {
		'a_form':a_form
	}

	return render(request, 'users/profile.html', context)

@login_required
def edit_profile(request):
	user = Profile.objects.get(user=request.user)
	if  request.method == 'POST':
		form = ChangeProfileForm(request.POST, request.FILES, instance=request.user.profile)
		if form.is_valid():
			form.save()
			print (user.image.url)
			return redirect('profile')
	else:
		form = ChangeProfileForm(instance=request.user.profile)
		return render (request, 'users/edit_profile.html',{'form':form})



@login_required
def add_amount(request):
	new_bal = request.POST.get('acc_bal')
	user = Profile.objects.get(user=request.user)
	user.acc_bal = user.acc_bal + int(new_bal)
	user.save()
	return redirect('/profile')


def block(request):
	usermail = request.user.email
	user = Profile.objects.get(user=request.user)
	send_mail('Vehicle BLOCKED', 'Hi Sir/Mam \nWe will try our best to help you find your vehicle. Your vehicle will not be able to pass the Toll Plaza until further instructions. We will inform the highway security Police and concerened authorities for the same.\n\nToll collection authority of INDIA', 'mogra.2@iitj.ac.in', ['mogra.2@iitj.ac.in', usermail])
	user.check=1
	user.save()
	return redirect('profile')

def unblock(request):
	usermail = request.user.email
	user = Profile.objects.get(user=request.user)
	send_mail('Vehicle UNBLOCKED', ' Hi Sir/Mam \n We are happy that your Vehicle has been found. Now you will be able to resume all the functionalities enjoyed by our users.\n\nToll collection authority of INDIA', 'mogra.2@iitj.ac.in', ['mogra.2@iitj.ac.in', usermail])
	user.check=0
	user.save()
	return redirect('profile')