from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from .models import Profile


class UserRegistrationForm(UserCreationForm):
 	email = forms.EmailField()
 	first_name = forms.CharField()
 	last_name = forms.CharField()
 	class Meta:
 		model = User
 		fields = (
 			'username',
 			'first_name',
 			'last_name',
 			'email',
 			'password1',
 			'password2'
		)
class addacountform(forms.ModelForm):
	class Meta:
		model = Profile
		fields = ['acc_bal']



class ChangeProfileForm(forms.ModelForm):
	class Meta:
		model = Profile
		fields = ['vehicle_no', 'age', 'driving_licence']
	