from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .forms import UserRegistrationForm, addacountform, ChangeProfileForm
from .models import Profile
from django.contrib.auth.forms import UserChangeForm

# Create your views here.
def register(request):
	if  request.method == 'POST':
		form = UserRegistrationForm(request.POST)
		if form.is_valid():
			form.save()
			return redirect('edit_profile')
	else:
		form= UserRegistrationForm()
	return render (request, 'users/register.html',{'form':form})

@login_required
def profile(request):
	if  request.method == 'POST':
		a_form = addacountform(request.POST, request.FILES, instance=request.user.profile)
		if a_form.is_valid():
			a_form.save()
#			acc_bal =  a_form.cleaned_data.get('acc_bal') + acc_bal.value
			return redirect('profile')
	else:
		a_form = addacountform(instance=request.user.profile)
	context = {
		'a_form':a_form
	}

	return render(request, 'users/profile.html', context)

@login_required
def edit_profile(request):
	user = Profile.objects.get(user=request.user)
	if  request.method == 'POST':
		form = ChangeProfileForm(request.POST, request.FILES, instance=request.user.profile)
		if form.is_valid():
			form.save()
			print (user.image.url)
			return redirect('profile')
	else:
		form = ChangeProfileForm(instance=request.user.profile)
		return render (request, 'users/edit_profile.html',{'form':form})



@login_required
def add_amount(request):
	new_bal = request.POST.get('acc_bal')
	user = Profile.objects.get(user=request.user)
	user.acc_bal = user.acc_bal + int(new_bal)
	user.save()
	return redirect('/profile')
